How to use:

1) create a directory for the script to reside
2) put files (including this one) into that directory
3) open top-right.html, goto line 81, and change the info for "player", "agency", "callsign" making sure to preserve the
   formatting and any quotes.  If you need a quote or other punctuation mark in your name/agency/callsign please refer to
   this: https://www.toptal.com/designers/htmlarrows/punctuation/   and utilize the code labelled as "HTML ENTITY".
4) load into OBS (or other software) as a "BROWSER SOURCE" the file with the .html extension
5) activate the layer and profit!

Version History:
v2: this one
v1: initially was 3 separate files.